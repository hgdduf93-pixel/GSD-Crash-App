# GSD CRASH Android WebView App

Website: https://gsdcrash.ai.studio

## Phone-only GitHub build
1. Create a GitHub repository.
2. Upload all files/folders from this project.
3. Open the repository's **Actions** tab.
4. Select **Build GSD CRASH APK**.
5. Tap **Run workflow**.
6. When finished, open the workflow run and download the **GSD-CRASH-APK** artifact.
7. Extract the artifact ZIP to get `app-debug.apk`.

This project contains no third-party APK-builder watermark or branding.
